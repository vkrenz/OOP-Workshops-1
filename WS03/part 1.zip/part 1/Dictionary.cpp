#include <iostream>
#include "Dictionary.h"

using namespace std;

namespace sdds {

    bool Dictionary::operator==(const Dictionary& other) const { return m_term == other.m_term; }

    bool Dictionary::operator!=(const Dictionary& other) const { return !(*this == other); }

    Dictionary& Dictionary::operator=(const Dictionary& other) {
        if (this != &other) {
            m_term = other.m_term;
            m_definition = other.m_definition;
        }

        return *this;
    }

} // namespace sddss