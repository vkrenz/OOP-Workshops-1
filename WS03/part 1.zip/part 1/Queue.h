#ifndef SDDS_QUEUE_H
#define SDDS_QUEUE_H

#include "Dictionary.h"

namespace sdds {
    
    template <typename T, unsigned int CAPACITY>
    class Queue {
        T collection[CAPACITY];
        unsigned int currentSize;
    public:
        Queue();

        unsigned int size() const;

        bool push(const T& item);
        T pop();
        void display(std::ostream& os = std::cout) const;
        T operator[](unsigned int index) const;
    };

    // template< /** Specialized */ >
    // class Queue<Dictionary, 100u> {
    //     Dictionary collection[100u];
    //     unsigned int currentSize;
    // public:
    //     Queue() : currentSize(0) {};

    //     unsigned int size() const { return currentSize; };

    //     bool push(const Dictionary& dict);
    //     Dictionary pop();
    //     void display(std::ostream& os = std::cout) const;
    //     Dictionary operator[](unsigned int index) const;
    // };

    template class Queue<long, 20u>;
    template class Queue<double, 30u>;
    template class Queue<Dictionary, 50u>;

} // QUEUE_H

#endif