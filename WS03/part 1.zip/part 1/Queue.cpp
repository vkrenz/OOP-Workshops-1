#include <iostream>
#include "Queue.h"

using namespace std;

namespace sdds {

    // Constructor
    template <typename T, unsigned int CAPACITY>
    Queue<T, CAPACITY>::Queue() : currentSize(0) {}

    // Push Function
    template <typename T, unsigned int CAPACITY>
    bool Queue<T, CAPACITY>::push(const T& item) {
        if (currentSize < CAPACITY) {
            collection[currentSize++] = item;
            return true;
        }
        return false;
    }

    // Pop Function
    template <typename T, unsigned int CAPACITY>
    T Queue<T, CAPACITY>::pop() {
        if (currentSize > 0) {
            T removed = collection[0];
            for (unsigned int i = 1; i < currentSize; i++) collection[i - 1] = collection[i];
            currentSize--;

            return removed;
        }
        return T();
    }

    // Size Function
    template <typename T, unsigned int CAPACITY>
    unsigned int Queue<T, CAPACITY>::size() const {
        return currentSize;
    }

    // Display Function
    template <typename T, unsigned int CAPACITY>
    void Queue<T, CAPACITY>::display(ostream& os = cout) const {
        for (unsigned int i = 0; i < currentSize; i++) os << collection[i] << " ";
        os << endl;
    }

    // Operator[] Function Overload
    template <typename T, unsigned int CAPACITY>
    T Queue<T, CAPACITY>::operator[](unsigned int index) const {
        if (index >= currentSize || index < 0) return T();
        return collection[index];
    }

    // Explicit instantiation for Dictionary and CAPACITY = 50
    template class Queue<Dictionary, 50u>;

} // namespace sdds