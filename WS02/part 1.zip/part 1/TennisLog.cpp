#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <string>
#include <cstring>
#include "TennisLog.h"

using namespace std;

namespace sdds {

    bool TennisMatch::isEmpty() const {
        return m_tourney_id == "0" || m_match_id <= 0;
    }

    // Match Getters & Setters

    string TennisMatch::getTourneyId() const { return m_tourney_id; };
    string TennisMatch::getTourneyName() const { return m_tourney_name; };
    unsigned int TennisMatch::getMatchId() const { return m_match_id; };
    string TennisMatch::getWinnerName() const { return m_winner_name; };
    string TennisMatch::getLoserName() const { return m_loser_name; };

    // void TennisMatch::setTourneyId(const string tourneyId) { if (tourneyId.length() > 0) m_tourney_id = tourneyId; };
    // void TennisMatch::setTourneyName(const string tourneyName) { if (tourneyName.length() > 0) m_tourney_name = tourneyName; };
    // void TennisMatch::setMatchId(const unsigned int matchId) { if (matchId > 0) m_match_id = matchId; };
    // void TennisMatch::setWinnerName(const string winnerName) { if (winnerName.length() > 0) m_winner_name = winnerName;};
    // void TennisMatch::setLoserName(const string loserName) { if (loserName.length() > 0) m_loser_name = loserName; };

    // TennisLog

    // Constructors  

    TennisMatch::TennisMatch(
        const string& tourneyId,
        const string& tourneyName,
        unsigned int matchId,
        const string& winnerName,
        const string& loserName
    ):
        m_tourney_id(tourneyId),
        m_tourney_name(tourneyName),
        m_match_id(matchId),
        m_winner_name(winnerName),
        m_loser_name(loserName)
    {
        if (m_tourney_id.empty()) m_tourney_id = "0";
    };

    TennisMatch::TennisMatch(): 
        m_tourney_id(""),
        m_tourney_name(""),
        m_match_id(0),
        m_winner_name(""),
        m_loser_name("")
    {};

    TennisLog::TennisLog():
        m_matches(nullptr),
        m_match_count(0)
    {};

    TennisLog::TennisLog(const string& filename):
        m_matches(nullptr),
        m_match_count(0)
    {
        ifstream file(filename);
        string line;

        // Skip the first line
        file.ignore('\n');

        // Count the number of matches
        while (getline(file, line)) {
            if (!line.empty()) {
                m_match_count++;
            }
        }

        // Skip the first line
        file.ignore('\n');

        // Allocate dynamic memory for the array of matches
        m_matches = new TennisMatch[m_match_count];

        // Reset filestream to the beginning
        file.clear();
        file.seekg(0, ios::beg);


        // Read data into the `m_matches` array
        static size_t index = 0;
        string field;
        char delimiter = ',';

        // Temp values
        unsigned int matchId;

        // Read `m_tourney_id`
        getline(file, m_matches[index].m_tourney_id, delimiter);
        file.ignore();

        // Read `m_tourney_name`
        getline(file, m_matches[index].m_tourney_name, delimiter);
        file.ignore();

        // Read `m_match_id`
        getline(file, field, delimiter);
        try {
            matchId = stoul(field);
            m_matches[index].m_match_id = matchId;
            file.ignore();
        }
        catch (std::invalid_argument& e) {
            std::cerr << "Invalid Match Id Argument: " << field << endl;
        }

        // Read `m_winner_name`
        getline(file, m_matches[index].m_winner_name, delimiter);
        file.ignore();

        // Read `m_loser_name`
        getline(file, m_matches[index].m_loser_name, delimiter);
        file.ignore();

        addMatch(m_matches[index]);

        index++;
    };

    // Public Functions

    void TennisLog::addMatch(const TennisMatch& match) {
        if (match.isEmpty()) return;

        // Create a new dynamic array
        TennisMatch* newMatches = new TennisMatch[m_match_count + 1];

        // Copy existing matches into `newMatches`
        for (size_t i = 0; i < m_match_count; i++) {
            newMatches[i] = m_matches[i];
        }

        // Add new match to the end of the `newMatches` array
        newMatches[m_match_count] = match;

        // Delete the old `m_matches` array
        delete[] m_matches;

        // Update the member variables with `newMatches` array and new `m_match_caount`
        m_matches = newMatches;
        m_match_count++;
    };

    TennisLog TennisLog::findMatches(const string& playerName) {
        // Create a new TennisLog object to match `m_matches`
        TennisLog tL;

        for (size_t i = 0; i < m_match_count; i++) {
            const TennisMatch& match = m_matches[i];

            // Check if `playerName` matches `m_winner_name` or `m_loser_name`
            if (match.m_winner_name == playerName || match.m_loser_name == playerName) {
                tL.addMatch(match);
            }
        }

        return tL;
    };

    TennisLog::~TennisLog() {
        delete[] m_matches;
    };

    TennisMatch TennisLog::operator[](size_t index) {
        if (index < m_match_count) {
            return m_matches[index];
        }
        else {
            static TennisMatch emptyMatch;
            return emptyMatch;
        }
    }

    TennisLog::operator size_t() {
        return m_match_count;
    }

    ostream& operator<<(ostream& os, const TennisMatch& match) {
        if (match.isEmpty()) {
            os << "Empty Match";
        }
        else {
            os  << setfill('.') << setw(20) << right << "Tourney ID : " << left << setw(30) << match.getTourneyId() << endl
                << setfill('.') << setw(20) << right << "Match ID : " << left << setw(30) << match.getMatchId() << endl
                << setfill('.') << setw(20) << right << "Tourney : " << left << setw(30) << match.getTourneyName() << endl
                << setfill('.') << setw(20) << right << "Winner : " << left << setw(30) << match.getWinnerName() << endl
                << setfill('.') << setw(20) << right << "Loser : " << left << setw(30) << match.getLoserName() << endl; 

            os << endl;
        }

        return os;
    }

} // namespace sdds 