#ifndef SDDS_TENNISLOG_H
#define SDDS_TENNISLOG_H

#include <string>

namespace sdds {

    struct TennisMatch {
    private:
        std::string m_tourney_id;
        std::string m_tourney_name;
        unsigned int m_match_id;
        std::string m_winner_name; // Winner of the match
        std::string m_loser_name; // Loser of the match
    public:
        friend class TennisLog;

        TennisMatch();
        TennisMatch(const std::string& tourneyId, const std::string& tourneyName, unsigned int matchId, const std::string& winnerName, const std::string& loserName);
        
        bool isEmpty() const;

        std::string getTourneyId() const;
        std::string getTourneyName() const;
        unsigned int getMatchId() const;
        std::string getWinnerName() const;
        std::string getLoserName() const;

        // void setTourneyId(const std::string tourneyId);
        // void setTourneyName(const std::string tourneyName);
        // void setMatchId(const unsigned int matchId);
        // void setWinnerName(const std::string winnerName);
        // void setLoserName(const std::string loserName);
    };

    class TennisLog {
        TennisMatch* m_matches;
        size_t m_match_count;
    public:
        TennisLog(); // Default constructor
        TennisLog(const std::string& filename); // One-argument constructor

        void addMatch(const TennisMatch& match);
        TennisLog findMatches(const std::string& playerName);

        TennisMatch operator[](size_t index);
        operator size_t();


        ~TennisLog(); // Destructor
    };

    std::ostream& operator<<(std::ostream& os, const TennisMatch& match);

}

#endif